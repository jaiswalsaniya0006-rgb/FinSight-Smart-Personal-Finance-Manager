# FinSight – Smart Personal Finance Manager (React)

A mobile-style personal finance app built with React + Vite.

## Features
- Dashboard with balance, monthly spending and safe-to-spend per day
- Add, search, filter and delete income/expense transactions
- Analytics by week / month / year with category breakdown
- Monthly and category budgets with progress bars
- Savings goals (create, add money, delete)
- Data saved in the browser (localStorage)

## Run locally
```
npm install
npm run dev
```
Then open the address shown in the terminal (usually http://localhost:5173).

## Project structure
```
src/
  main.jsx            entry point
  App.jsx             app state, navigation, popup and toast
  data.js             sample data, constants, helper functions
  index.css           all styling
  components/         Nav, TxRow, Sheet (reusable pieces)
  screens/            Home, Transactions, AddTransaction, Analytics,
                      Budget, Savings, Profile
```
