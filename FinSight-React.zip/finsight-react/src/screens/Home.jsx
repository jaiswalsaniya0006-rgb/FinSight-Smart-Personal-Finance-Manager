import { fmt, sum, ofType, mRange, sorted } from '../data.js'
import TxRow from '../components/TxRow.jsx'

export default function Home({ S, go, toast }) {
  const income = sum(S.tx.filter((t) => t.type === 'Income'))
  const expenses = sum(S.tx.filter((t) => t.type === 'Expense'))
  const spent = sum(ofType(S.tx, 'Expense', ...mRange()))
  const pct = S.budget > 0 ? Math.round((spent / S.budget) * 100) : 0
  const now = new Date()
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()
  const safe = Math.max(0, (S.budget - spent) / (daysInMonth - now.getDate() + 1))
  const over = spent > S.budget

  return (
    <>
      <div className="top">
        <div className="brand">
          <div className="logo">F</div>
          <div><h3>FinSight</h3><small>SMART FINANCE</small></div>
        </div>
        <button className="ibtn" onClick={() => toast('No new notifications')}>♧</button>
      </div>

      <div className="welcome">
        <small>WELCOME BACK</small>
        <h2>Hello, {S.name.split(' ')[0]}!</h2>
        <p className="mut">Here's your financial overview.</p>
      </div>

      <div className="bal">
        <p>Total Balance</p>
        <h1>{fmt(income - expenses)}</h1>
        <div className="row">
          <div><small>↗ Income</small><b>{fmt(income)}</b></div>
          <div><small>↘ Expenses</small><b>{fmt(expenses)}</b></div>
        </div>
      </div>

      <div className="card split">
        <div>
          <p>Monthly Spending</p>
          <h2>{fmt(spent)}</h2>
          <small className={over ? 'r' : 'g'}>{pct}% of budget used</small>
        </div>
        <div className="ring" style={{ background: `conic-gradient(${over ? 'var(--r)' : 'var(--g)'} ${Math.min(pct, 100) * 3.6}deg,#46504c 0)` }}>
          <span>{pct}%</span>
        </div>
      </div>

      <div className="card split">
        <div>
          <p>Safe to Spend</p>
          <h2>{fmt(Math.round(safe))}/day</h2>
          <small className={over ? 'r' : 'g'}>{over ? "You're over budget" : "You're on track!"}</small>
        </div>
        <span className="big">✦</span>
      </div>

      <h3 className="sec">Quick Actions</h3>
      <div className="qa">
        <button onClick={() => go('add', 'Expense')}><span>＋</span><small>Add Expense</small></button>
        <button onClick={() => go('add', 'Income')}><span>↗</span><small>Add Income</small></button>
        <button onClick={() => go('budget')}><span>◎</span><small>Set Budget</small></button>
      </div>

      <div className="head">
        <h3>Recent Transactions</h3>
        <button className="link" onClick={() => go('transactions')}>See all</button>
      </div>
      {S.tx.length === 0 && <p className="mut empty">No transactions yet. Add your first one.</p>}
      {sorted(S.tx).slice(0, 4).map((t) => <TxRow key={t.id} t={t} />)}
    </>
  )
}
