import { useState } from 'react'
import { fmt, sum, ofType, mRange, ymd, ago, today, pad2, ICONS } from '../data.js'

// Works out the date ranges and chart bars for week / month / year
function periodData(tx, period) {
  let cur, prv, buckets = [], labels = []
  if (period === 'week') {
    cur = [ago(6), today()]; prv = [ago(13), ago(7)]
    for (let i = 6; i >= 0; i--) {
      const x = new Date(); x.setDate(x.getDate() - i)
      buckets.push(sum(ofType(tx, 'Expense', ymd(x), ymd(x))))
      labels.push(x.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 2))
    }
  } else if (period === 'year') {
    const y = new Date().getFullYear()
    cur = [y + '-01-01', y + '-12-31']; prv = [y - 1 + '-01-01', y - 1 + '-12-31']
    for (let m = 1; m <= 12; m++) {
      const p = y + '-' + pad2(m)
      buckets.push(sum(ofType(tx, 'Expense', p + '-01', p + '-31')))
      labels.push('JFMAMJJASOND'[m - 1])
    }
  } else {
    cur = mRange(); prv = mRange(-1); buckets = [0, 0, 0, 0]; labels = ['W1', 'W2', 'W3', 'W4']
    ofType(tx, 'Expense', ...cur).forEach((t) => { buckets[Math.min(Math.floor((+t.date.slice(8) - 1) / 7), 3)] += Number(t.amount) })
  }
  return { cur, prv, buckets, labels }
}

export default function Analytics({ S }) {
  const [period, setPeriod] = useState('month')
  const { cur, prv, buckets, labels } = periodData(S.tx, period)
  const exp = ofType(S.tx, 'Expense', ...cur)
  const total = sum(exp)
  const income = sum(ofType(S.tx, 'Income', ...cur))
  const prevTotal = sum(ofType(S.tx, 'Expense', ...prv))
  const change = prevTotal > 0 ? ((total - prevTotal) / prevTotal) * 100 : null
  const word = { week: 'last week', month: 'last month', year: 'last year' }[period]
  const max = Math.max(...buckets, 1)

  const cats = {}
  exp.forEach((t) => { cats[t.category] = (cats[t.category] || 0) + Number(t.amount) })
  const entries = Object.entries(cats).sort((a, b) => b[1] - a[1])

  return (
    <>
      <div className="top"><h2>Analytics</h2></div>
      <p className="mut">Understand your spending habits.</p>
      <div className="chips">
        {['week', 'month', 'year'].map((p) => (
          <button key={p} className={period === p ? 'on' : ''} onClick={() => setPeriod(p)}>{p[0].toUpperCase() + p.slice(1)}</button>
        ))}
      </div>

      <div className="card">
        <small className="mut">Total Expenses</small>
        <h1>{fmt(total)}</h1>
        <small className={change !== null && change > 0 ? 'r' : 'g'}>
          {change === null ? 'No data for ' + word : (change > 0 ? '↑ ' : '↓ ') + Math.abs(change).toFixed(1) + '% compared to ' + word}
        </small>
        <div className="chart">
          {buckets.map((v, i) => (
            <div key={i} style={{ height: (v ? Math.max((v / max) * 100, 6) : 4) + '%', opacity: v ? 1 : 0.3 }}>
              <small>{labels[i]}</small>
            </div>
          ))}
        </div>
      </div>

      <h3 className="sec">Income vs Expenses</h3>
      <div className="two">
        <div className="card"><small>Income</small><h3 className="g">{fmt(income)}</h3></div>
        <div className="card"><small>Expenses</small><h3 className="r">{fmt(total)}</h3></div>
      </div>

      <h3 className="sec">Spending by Category</h3>
      <div className="card">
        {entries.length === 0 && <p className="mut">No expense data for this period.</p>}
        {entries.map(([c, a]) => (
          <div key={c}>
            <div className="crow"><span>{ICONS[c]} {c}</span><b>{fmt(a)}</b></div>
            <div className="bar"><i style={{ width: (a / total) * 100 + '%' }}></i></div>
          </div>
        ))}
      </div>

      <div className="card">
        <small className="g">SPENDING INSIGHT</small>
        <p className="mut" style={{ marginTop: 10, color: '#d0d6df' }}>
          {entries.length
            ? `Your highest spending category in this period is ${entries[0][0]} (${Math.round((entries[0][1] / total) * 100)}% of expenses).`
            : 'Add some expenses to see insights.'}
        </p>
      </div>
    </>
  )
}
