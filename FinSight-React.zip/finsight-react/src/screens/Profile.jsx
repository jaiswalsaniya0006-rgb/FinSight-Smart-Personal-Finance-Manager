import { seed } from '../data.js'
import { Field } from '../components/Sheet.jsx'

function MenuItem({ icon, title, sub, onClick }) {
  return (
    <button className="menu" onClick={onClick}>
      <span>{icon}</span>
      <div><b>{title}</b><small>{sub}</small></div>
      <strong>›</strong>
    </button>
  )
}

export default function Profile({ S, setS, go, toast, openSheet }) {
  const editProfile = () =>
    openSheet(
      'Edit profile',
      <Field label="Full name" name="name" defaultValue={S.name} required />,
      (d) => { setS((s) => ({ ...s, name: d.name.trim() || s.name })); toast('Profile updated') }
    )

  const confirm = (title, text, action, ok) =>
    openSheet(title, <p className="mut" style={{ marginBottom: 16 }}>{text}</p>, action, ok)

  return (
    <>
      <div className="top">
        <h2>My Profile</h2>
        <button className="ibtn" onClick={() => toast('Settings coming soon')}>⚙</button>
      </div>

      <div className="prof">
        <div className="av">{(S.name[0] || 'U').toUpperCase()}</div>
        <h2>{S.name}</h2>
        <p className="mut">saniya@example.com</p>
        <button className="btn" onClick={editProfile}>Edit Profile</button>
      </div>

      <h3 className="sec">Account</h3>
      <MenuItem icon="🎯" title="Savings Goals" sub="Track your financial goals" onClick={() => go('savings')} />
      <MenuItem icon="◎" title="Budget" sub="Manage monthly limits" onClick={() => go('budget')} />
      <MenuItem icon="💳" title="My Accounts" sub="Manage your accounts" onClick={() => toast('Accounts coming soon')} />
      <MenuItem icon="🔔" title="Reminders" sub="Manage upcoming bills" onClick={() => toast('Reminders coming soon')} />

      <h3 className="sec">Preferences</h3>
      <MenuItem icon="🌙" title="Appearance" sub="Dark theme" onClick={() => toast('Dark theme is active')} />
      <MenuItem icon="💱" title="Currency" sub="Indian Rupee (INR)" onClick={() => toast('Currency is set to INR')} />
      <MenuItem icon="🗑️" title="Reset Data" sub="Restore the sample data" onClick={() => confirm('Reset data?', 'Everything will be replaced with the sample data.', () => { setS(seed()); go('home'); toast('Sample data restored') }, 'Reset')} />
      <MenuItem icon="🧹" title="Clear All Data" sub="Start with a blank slate" onClick={() => confirm('Clear all data?', 'All transactions and goals will be deleted.', () => { setS((s) => ({ ...s, tx: [], goals: [], cb: {} })); go('home'); toast('All data cleared') }, 'Clear')} />
      <button className="logout" onClick={() => toast('Logged out (demo)')}>Log Out</button>
    </>
  )
}
