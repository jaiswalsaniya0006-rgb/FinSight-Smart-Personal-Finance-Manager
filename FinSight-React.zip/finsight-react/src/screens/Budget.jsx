import { fmt, sum, ofType, mRange, CATS, ICONS } from '../data.js'
import { Field } from '../components/Sheet.jsx'

export default function Budget({ S, setS, openSheet, toast, onBack }) {
  const spent = sum(ofType(S.tx, 'Expense', ...mRange()))
  const left = S.budget - spent
  const pct = S.budget ? Math.min((spent / S.budget) * 100, 100) : 0
  const catSpent = (c) => sum(ofType(S.tx, 'Expense', ...mRange()).filter((t) => t.category === c))

  const edit = () => {
    const cats = [...new Set([...Object.keys(S.cb), ...CATS.Expense])]
    openSheet(
      'Edit budgets',
      <>
        <Field label="Total monthly budget (₹)" name="total" type="number" min="0" step="1" defaultValue={S.budget} required />
        <p className="mut" style={{ marginBottom: 10 }}>Category limits (leave blank to remove)</p>
        {cats.map((c) => (
          <Field key={c} label={c} name={'c_' + c} type="number" min="0" step="1" placeholder="No limit" defaultValue={S.cb[c] ?? ''} />
        ))}
      </>,
      (d) => {
        const cb = {}
        cats.forEach((c) => { if (d['c_' + c] !== '' && Number(d['c_' + c]) > 0) cb[c] = Number(d['c_' + c]) })
        setS((s) => ({ ...s, budget: Number(d.total) || 0, cb }))
        toast('Budget updated')
      }
    )
  }

  return (
    <>
      <div className="top">
        <button className="back" onClick={onBack}>‹</button>
        <h2>My Budget</h2>
        <button className="ibtn" onClick={edit}>＋</button>
      </div>
      <p className="mut" style={{ marginBottom: 16 }}>Manage your monthly spending limits.</p>

      <div className="card">
        <small>Total Monthly Budget</small>
        <h1>{fmt(S.budget)}</h1>
        <div className="nums">
          <span>Spent <b>{fmt(spent)}</b></span>
          <span>{left < 0 ? 'Over by' : 'Left'} <b className={left < 0 ? 'r' : 'g'}>{fmt(Math.abs(left))}</b></span>
        </div>
        <div className={'bar ' + (left < 0 ? 'over' : '')}><i style={{ width: pct + '%' }}></i></div>
        <small className="mut">{Math.round(S.budget ? (spent / S.budget) * 100 : 0)}% of your budget used</small>
      </div>

      <div className="head">
        <h3>Category Budgets</h3>
        <button className="link" onClick={edit}>Edit</button>
      </div>
      {Object.keys(S.cb).length === 0 && <p className="mut empty">No category budgets yet.</p>}
      {Object.entries(S.cb).map(([c, limit]) => {
        const s = catSpent(c)
        const over = s > limit
        return (
          <div className="card" key={c}>
            <div className="crow" style={{ marginTop: 0 }}><span>{ICONS[c]} {c}</span><b>{fmt(s)} / {fmt(limit)}</b></div>
            <div className={'bar ' + (over ? 'over' : '')}><i style={{ width: (limit ? Math.min((s / limit) * 100, 100) : 0) + '%' }}></i></div>
            <small className={over ? 'r' : 'mut'} style={{ fontSize: 10 }}>{over ? fmt(s - limit) + ' over limit' : fmt(limit - s) + ' remaining'}</small>
          </div>
        )
      })}
      <button className="btn" onClick={edit}>＋ Create New Budget</button>
    </>
  )
}
