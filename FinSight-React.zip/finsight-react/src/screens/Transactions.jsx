import { useState } from 'react'
import { sorted } from '../data.js'
import TxRow from '../components/TxRow.jsx'

export default function Transactions({ S, setS, openSheet, toast }) {
  const [filter, setFilter] = useState('All')
  const [q, setQ] = useState('')

  let list = sorted(S.tx)
  if (filter !== 'All') list = list.filter((t) => t.type === filter)
  if (q) list = list.filter((t) => (t.title + ' ' + t.category).toLowerCase().includes(q.toLowerCase()))

  const remove = (id) =>
    openSheet(
      'Delete transaction?',
      <p className="mut" style={{ marginBottom: 16 }}>This can't be undone.</p>,
      () => { setS((s) => ({ ...s, tx: s.tx.filter((t) => t.id !== id) })); toast('Transaction deleted') },
      'Delete'
    )

  return (
    <>
      <div className="top"><h2>Transactions</h2></div>
      <p className="mut">Track your income and expenses.</p>
      <input className="search" type="search" placeholder="Search transactions..." value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="chips">
        {['All', 'Income', 'Expense'].map((f) => (
          <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      <div className="head" style={{ marginTop: 6 }}>
        <h3>Recent Activity</h3>
        <small className="mut">{new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })}</small>
      </div>
      {list.length === 0 && <p className="mut empty">No transactions found.</p>}
      {list.map((t) => <TxRow key={t.id} t={t} onDelete={() => remove(t.id)} />)}
    </>
  )
}
