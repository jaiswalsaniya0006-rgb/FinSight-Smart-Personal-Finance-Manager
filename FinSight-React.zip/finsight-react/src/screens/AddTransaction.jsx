import { useState } from 'react'
import { CATS, PAY, today } from '../data.js'

export default function AddTransaction({ initialType, setS, go, toast, onBack }) {
  const [type, setType] = useState(initialType)
  const [msg, setMsg] = useState('')

  const submit = (e) => {
    e.preventDefault()
    const d = Object.fromEntries(new FormData(e.target))
    const amount = Number(d.amount)
    if (!(amount > 0) || !d.title.trim() || !d.category || !d.date || !d.payment) {
      setMsg('Please enter all required details.')
      return
    }
    const newTx = { id: Date.now(), title: d.title.trim(), type, category: d.category, amount, date: d.date, payment: d.payment, notes: (d.notes || '').trim() }
    setS((s) => ({ ...s, tx: [...s.tx, newTx] }))
    toast(type + ' saved')
    go('transactions')
  }

  return (
    <>
      <div className="top">
        <button className="back" onClick={onBack}>‹</button>
        <h2>Add Transaction</h2>
        <span style={{ width: 30 }}></span>
      </div>
      <p className="mut">Record your income or expenses.</p>

      <form onSubmit={submit} autoComplete="off">
        <div className="seg">
          {['Expense', 'Income'].map((t) => (
            // key changes with type so the category select resets
            <button type="button" key={t} className={type === t ? 'on' : ''} onClick={() => setType(t)}>{t}</button>
          ))}
        </div>

        <div className="amt">
          <small>ENTER AMOUNT</small>
          <input name="amount" type="number" inputMode="decimal" min="0.01" step="0.01" placeholder="₹ 0.00" required />
          <p className="mut" style={{ fontSize: 10 }}>Enter transaction amount</p>
        </div>

        <div className="fg"><label htmlFor="title">Transaction Title</label><input className="in" id="title" name="title" placeholder="e.g. Grocery shopping" required /></div>
        <div className="fg">
          <label htmlFor="category">Category</label>
          <select className="in" id="category" name="category" key={type} required defaultValue="">
            <option value="">Select Category</option>
            {CATS[type].map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="fg"><label htmlFor="date">Date</label><input className="in" id="date" type="date" name="date" defaultValue={today()} required /></div>
        <div className="fg">
          <label htmlFor="payment">Payment Method</label>
          <select className="in" id="payment" name="payment" required defaultValue="">
            <option value="">Select Payment Method</option>
            {PAY.map((p) => <option key={p}>{p}</option>)}
          </select>
        </div>
        <div className="fg"><label htmlFor="notes">Notes (Optional)</label><input className="in" id="notes" name="notes" placeholder="Add a note..." /></div>

        <button className="btn">Save Transaction</button>
        <p className="msg r">{msg}</p>
      </form>
    </>
  )
}
