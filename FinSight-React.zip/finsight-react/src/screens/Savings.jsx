import { fmt } from '../data.js'
import { Field } from '../components/Sheet.jsx'

const dueLabel = (v) =>
  v ? 'Target: ' + new Date(v + '-01T12:00:00').toLocaleDateString('en-GB', { month: 'short', year: 'numeric' }) : 'No target date'

export default function Savings({ S, setS, openSheet, toast, onBack }) {
  const total = S.goals.reduce((a, g) => a + g.saved, 0)

  const newGoal = () =>
    openSheet(
      'New savings goal',
      <>
        <Field label="Goal name" name="name" placeholder="e.g. New phone" required />
        <Field label="Target amount (₹)" name="target" type="number" min="1" required />
        <Field label="Already saved (₹)" name="saved" type="number" min="0" defaultValue="0" />
        <Field label="Target month" name="due" type="month" />
        <div className="fg">
          <label htmlFor="icon">Icon</label>
          <select className="in" id="icon" name="icon">
            {['🎯', '✈️', '🛡️', '💻', '🏠', '🚗', '📱', '🎓'].map((i) => <option key={i}>{i}</option>)}
          </select>
        </div>
      </>,
      (d) => {
        const goal = { id: Date.now(), name: d.name.trim(), icon: d.icon, kind: 'Personal Goal', saved: Number(d.saved) || 0, target: Number(d.target), due: d.due }
        setS((s) => ({ ...s, goals: [...s.goals, goal] }))
        toast('Goal created')
      }
    )

  const fund = (g) =>
    openSheet(
      'Add to ' + g.name,
      <Field label="Amount (₹)" name="amt" type="number" min="1" required />,
      (d) => {
        setS((s) => ({ ...s, goals: s.goals.map((x) => (x.id === g.id ? { ...x, saved: x.saved + Number(d.amt) } : x)) }))
        toast('Money added')
      }
    )

  const remove = (g) =>
    openSheet(
      'Delete goal?',
      <p className="mut" style={{ marginBottom: 16 }}>This goal and its progress will be removed.</p>,
      () => setS((s) => ({ ...s, goals: s.goals.filter((x) => x.id !== g.id) })),
      'Delete'
    )

  return (
    <>
      <div className="top">
        <button className="back" onClick={onBack}>‹</button>
        <h2>Savings Goals</h2>
        <button className="ibtn" onClick={newGoal}>＋</button>
      </div>
      <p className="mut" style={{ marginBottom: 16 }}>Save today for your tomorrow.</p>

      <div className="card">
        <small>Total Savings</small>
        <h1>{fmt(total)}</h1>
        <p className="g" style={{ fontSize: 12 }}>Across all your goals</p>
      </div>

      <div className="head"><h3>Your Goals</h3></div>
      {S.goals.length === 0 && <p className="mut empty">No goals yet. Create one to get started.</p>}
      {S.goals.map((g) => {
        const p = g.target ? Math.min(Math.round((g.saved / g.target) * 100), 100) : 0
        return (
          <div className="card goal" key={g.id}>
            <div className="goalh">
              <div className="ico">{g.icon}</div>
              <div><h3>{g.name}</h3><small className="mut" style={{ fontSize: 10 }}>{g.kind}</small></div>
              <button className="link r" onClick={() => remove(g)}>Delete</button>
            </div>
            <h2>{fmt(g.saved)} <small>/ {fmt(g.target)}</small></h2>
            <div className="bar"><i style={{ width: p + '%' }}></i></div>
            <div className="foot">
              <small className="g">{p}% completed</small>
              <small className="mut">{dueLabel(g.due)}</small>
              <button className="mini" onClick={() => fund(g)}>＋ Add money</button>
            </div>
          </div>
        )
      })}
      <button className="btn" onClick={newGoal}>＋ Create New Goal</button>
    </>
  )
}
