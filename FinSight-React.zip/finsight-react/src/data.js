// Shared data, constants and helper functions

export const KEY = 'finsight_react_v1'
export const ICONS = { 'Food & Dining': '🍔', Shopping: '🛍️', Transport: '🚕', Entertainment: '🎬', Health: '💊', Education: '📚', Bills: '📄', Salary: '💰', Freelance: '💻', Gift: '🎁', Other: '📦' }
export const CATS = {
  Expense: ['Food & Dining', 'Shopping', 'Transport', 'Entertainment', 'Health', 'Education', 'Bills', 'Other'],
  Income: ['Salary', 'Freelance', 'Gift', 'Other'],
}
export const PAY = ['UPI', 'Cash', 'Debit Card', 'Credit Card', 'Net Banking', 'Bank Transfer']

export const fmt = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })
const pad = (n) => String(n).padStart(2, '0')
export const ymd = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
export const today = () => ymd(new Date())
export const ago = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return ymd(d) }
export const pad2 = pad

export const sum = (arr) => arr.reduce((a, t) => a + Number(t.amount), 0)
export const ofType = (tx, type, from, to) =>
  tx.filter((t) => t.type === type && (!from || t.date >= from) && (!to || t.date <= to))
export const mRange = (off = 0) => {
  const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() + off)
  const p = d.getFullYear() + '-' + pad(d.getMonth() + 1)
  return [p + '-01', p + '-31']
}
export const sorted = (a) => [...a].sort((x, y) => y.date.localeCompare(x.date) || y.id - x.id)
export const nice = (d) => {
  if (d === today()) return 'Today'
  if (d === ago(1)) return 'Yesterday'
  return new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
}

export function seed() {
  const n = new Date()
  const first = ymd(new Date(n.getFullYear(), n.getMonth(), 1))
  let id = 1
  const t = (title, type, category, amount, date, payment) => ({ id: id++, title, type, category, amount, date, payment, notes: '' })
  return {
    name: 'Saniya Jaiswal',
    budget: 35000,
    cb: { 'Food & Dining': 8000, Transport: 5000, Shopping: 8000, Bills: 7000 },
    goals: [
      { id: 1, name: 'Japan Trip', icon: '✈️', kind: 'Travel Goal', saved: 30000, target: 100000, due: '2027-12' },
      { id: 2, name: 'Emergency Fund', icon: '🛡️', kind: 'Safety Goal', saved: 5000, target: 30000, due: '2027-06' },
      { id: 3, name: 'New Laptop', icon: '💻', kind: 'Personal Goal', saved: 0, target: 50000, due: '' },
    ],
    tx: [
      t('Salary', 'Income', 'Salary', 45000, first, 'Bank Transfer'),
      t('Electricity bill', 'Expense', 'Bills', 2100, first, 'Net Banking'),
      t('Shopping', 'Expense', 'Shopping', 1200, ago(5), 'Debit Card'),
      t('Transport', 'Expense', 'Transport', 250, ago(2), 'UPI'),
      t('Coffee', 'Expense', 'Food & Dining', 120, ago(1), 'UPI'),
      t('Food & Dining', 'Expense', 'Food & Dining', 350, ago(0), 'UPI'),
    ],
  }
}
