import { useState, useEffect, useRef } from 'react'
import { KEY, seed } from './data.js'
import Nav from './components/Nav.jsx'
import Sheet from './components/Sheet.jsx'
import Home from './screens/Home.jsx'
import Transactions from './screens/Transactions.jsx'
import AddTransaction from './screens/AddTransaction.jsx'
import Analytics from './screens/Analytics.jsx'
import Budget from './screens/Budget.jsx'
import Savings from './screens/Savings.jsx'
import Profile from './screens/Profile.jsx'

export default function App() {
  // All app data lives in one state object and is saved to localStorage
  const [S, setS] = useState(() => {
    try { const raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw) } catch (e) {}
    return seed()
  })
  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(S)) } catch (e) {}
  }, [S])

  const [route, setRoute] = useState('home')
  const [prev, setPrev] = useState('home')
  const [addType, setAddType] = useState('Expense')
  const [sheet, setSheet] = useState(null)
  const [toastMsg, setToastMsg] = useState('')
  const viewRef = useRef(null)
  const timer = useRef(null)

  useEffect(() => { if (viewRef.current) viewRef.current.scrollTop = 0 }, [route])

  const go = (name, type) => {
    if (name === 'add' || name === 'budget') setPrev(route)
    if (name === 'add') setAddType(type || 'Expense')
    setRoute(name)
  }
  const toast = (msg) => {
    setToastMsg(msg)
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setToastMsg(''), 1800)
  }
  const openSheet = (title, body, onSave, ok = 'Save') => setSheet({ title, body, onSave, ok })

  const props = { S, setS, go, toast, openSheet }

  return (
    <div className="phone" id="app">
      <div id="view" ref={viewRef}>
        {route === 'home' && <Home {...props} />}
        {route === 'transactions' && <Transactions {...props} />}
        {route === 'add' && <AddTransaction {...props} initialType={addType} onBack={() => go(prev === 'add' ? 'home' : prev)} />}
        {route === 'analytics' && <Analytics {...props} />}
        {route === 'budget' && <Budget {...props} onBack={() => go(prev === 'budget' ? 'home' : prev)} />}
        {route === 'savings' && <Savings {...props} onBack={() => go('profile')} />}
        {route === 'profile' && <Profile {...props} />}
      </div>
      <Nav route={route} go={go} />
      <Sheet sheet={sheet} onClose={() => setSheet(null)} />
      <div id="toast" className={toastMsg ? 'show' : ''}>{toastMsg}</div>
    </div>
  )
}
