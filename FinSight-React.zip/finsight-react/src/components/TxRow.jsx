import { ICONS, fmt, nice } from '../data.js'

export default function TxRow({ t, onDelete }) {
  const income = t.type === 'Income'
  return (
    <div className="tx">
      <div className="ico">{ICONS[t.category] || '📦'}</div>
      <div className="inf">
        <b>{t.title}</b>
        <small>{nice(t.date)} · {t.payment || t.category}</small>
      </div>
      <div>
        <strong className={income ? 'g' : 'r'}>{income ? '+' : '-'}{fmt(t.amount)}</strong>
        {onDelete && <button className="del" onClick={onDelete}>Delete</button>}
      </div>
    </div>
  )
}
