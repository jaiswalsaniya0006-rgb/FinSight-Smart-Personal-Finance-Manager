// Bottom popup used for forms and confirmations
export default function Sheet({ sheet, onClose }) {
  if (!sheet) return null
  const submit = (e) => {
    e.preventDefault()
    const data = Object.fromEntries(new FormData(e.target))
    if (sheet.onSave(data) !== false) onClose()
  }
  return (
    <div id="sheet" className="open">
      <form onSubmit={submit}>
        <h3>{sheet.title}</h3>
        {sheet.body}
        <div className="acts">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn">{sheet.ok}</button>
        </div>
      </form>
    </div>
  )
}

export function Field({ label, name, ...rest }) {
  return (
    <div className="fg">
      <label htmlFor={name}>{label}</label>
      <input className="in" id={name} name={name} {...rest} />
    </div>
  )
}
