const ITEMS = [
  ['home', '⌂', 'Home'],
  ['transactions', '☷', 'Transactions'],
  ['analytics', '▥', 'Analytics'],
  ['profile', '♙', 'Profile'],
]
// Which tab stays highlighted for sub-screens
const MAP = { home: 'home', transactions: 'transactions', add: '', analytics: 'analytics', budget: 'analytics', profile: 'profile', savings: 'profile' }

export default function Nav({ route, go }) {
  return (
    <nav id="nav">
      {ITEMS.map(([key, icon, label]) => (
        <button key={key} className={MAP[route] === key ? 'on' : ''} onClick={() => go(key)}>
          <span>{icon}</span>
          <small>{label}</small>
        </button>
      ))}
    </nav>
  )
}
